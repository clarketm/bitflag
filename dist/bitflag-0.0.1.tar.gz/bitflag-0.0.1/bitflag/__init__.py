from bitflag.BitFlag import BitFlag
# from bitflag.TestBitFlag import TestBitFlag
