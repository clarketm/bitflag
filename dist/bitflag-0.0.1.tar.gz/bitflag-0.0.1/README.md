# BitFlag

A bit flag class for python